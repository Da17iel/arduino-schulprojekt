<?php include "../Templates/header.php" ?>
<script>document.title = "Starter Page";</script>

<div class="mainContentHolder">
    <div class="ContentBox">
        <h1>Dies ist unsere HomePage</h1>
        <p>Bitte logged Sie sich ein, um mehr zu erfahren</p>
        <a href="../auth/login.php">Login</a>
        <a href="../auth/register.php">Register</a>
    </div>
</div>

<?php include "../Templates/footer.php" ?>